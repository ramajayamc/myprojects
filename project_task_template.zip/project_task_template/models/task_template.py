from odoo import api, fields, models, _


class TaskTemplate(models.Model):
    _name = 'project.task.template'

    name = fields.Char(string='Task Title', track_visibility='always', required=True, help=" The Title Of Task")
    user_id = fields.Many2one('res.users', string='Assigned to', index=True, track_visibility='always',
                              help="Many2one Field Related To res user")
    date_schedule = fields.Date(string='Schedule Date')
    date_deadline = fields.Date(string='Deadline', copy=False, help="Date Field For Deadline")
    description = fields.Html(string='Description', help="Html Field For Description")
    active = fields.Boolean(default=True, help="Boolean Field For Task Status")
    subtask_count = fields.Integer(compute='_compute_subtask_count', type='integer', string="Sub-task count")
    parent_id = fields.Many2one('project.task.template', string='Parent Task', index=True)
    child_ids = fields.One2many('project.task.template', 'parent_id', string="Sub-tasks", context={'active_test': False})
    stage_id = fields.Many2one('project.task.type',string='Stage')



    def action_subtask(self):
        action = self.env.ref('project_task_template.open_view_task_template_form').read()[0]
        ctx = self.env.context.copy()
        ctx.update({
            'default_parent_id' : self.id,
            'default_name' : self.env.context.get('name', self.name) + ':',
        })
        action['context'] = ctx
        action['domain'] = [('id', 'child_of', self.id), ('id', '!=', self.id)]
        return action

    @api.multi
    def _compute_subtask_count(self):
        for task in self:
            task.subtask_count = self.search_count([('id', 'child_of', task.id), ('id', '!=', task.id)])

from odoo import api, fields, models, _


class ProjectTemplate(models.Model):
    _name = "project.template"
    _description = "Project Template"

    task_tmp_ids = fields.Many2many('project.task.template', string='Tasks')
    name = fields.Char(string='Task Title', required=True, help=" The Title Of Task")


class Project(models.Model):
    _inherit = "project.project"
    _description = "Project"

    project_tmp_id = fields.Many2one('project.template', string="Template")

    @api.model
    def create(self, vals):
        variable = super(Project, self).create(vals)
        if 'project_tmp_id' in vals:
            template = self.env['project.template'].search([('id', '=', vals['project_tmp_id'])], limit=1)
            for temp in template.task_tmp_ids:
                task = {}
                task['name'] = temp.name
                task['project_id'] = variable.id
                # task['stage_id'] = stage_id.id
                rec = self.env['project.task'].create(task)
                for child in temp.child_ids:
                    child_task = {}
                    child_task['name'] = child.name
                    child_task['parent_id'] = rec.id
                    # child_task['stage_id'] = stage_id.id
                    child_task['project_id'] = variable.id
                    res = self.env['project.task'].create(child_task)
                    for sub_child in child.child_ids:
                        child_task2 = {}
                        child_task2['name'] = sub_child.name
                        child_task2['parent_id'] = res.id
                        # child_task2['stage_id'] = stage_id.id
                        child_task2['project_id'] = variable.id
                        res = self.env['project.task'].create(child_task2)
        return variable

from odoo import models, api, fields, _


class ProjectDetails(models.TransientModel):
    _name = 'project.details'

    template_id = fields.Many2one('project.template', string='Templates')
    name = fields.Char(string='Project Name')
    user_id = fields.Many2one('res.users', string='Project Manager')
    # stage_id = fields.Many2one('project.project.type', string='Stages')

    @api.multi
    def create_project(self):
        # variable = super(ProjectDetails, self).write(vals)
        proj_obj = self.env['project.project'].create({'name': self.name, 'user_id': self.user_id.id})
        # if 'name' in vals:
        template = self.env['project.template'].search([('id', '=', self.template_id.id)])
        for temp in template.task_tmp_ids:
            task = {}
            task['name'] = temp.name
            task['project_id'] = proj_obj.id
            # task['user_id'] = proj_obj.id
            # task['stage_id'] = stage_id.id
            rec = self.env['project.task'].create(task)
            for child in temp.child_ids:
                child_task = {}
                child_task['name'] = child.name
                child_task['parent_id'] = rec.id
                # child_task['stage_id'] = stage_id.id
                child_task['project_id'] = proj_obj.id
                # child_task['user_id'] = proj_obj.id
                res = self.env['project.task'].create(child_task)
                for sub_child in child.child_ids:
                    child_task2 = {}
                    child_task2['name'] = sub_child.name
                    child_task2['parent_id'] = res.id
                    # child_task2['stage_id'] = stage_id.id
                    child_task2['project_id'] = proj_obj.id
                    # child_task2['user_id'] = proj_obj.id
                    res = self.env['project.task'].create(child_task2)
        # return variable

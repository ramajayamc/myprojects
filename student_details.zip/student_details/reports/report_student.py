from odoo import api, fields, models, _

class AdminFormReport(models.AbstractModel):
    _name = 'report.student_student.student_stu_print'

    @api.multi
    def get_report_values(self, ids, data=None):
        report_obj = self.env['student.student'].browse(ids)
        return {
            'doc_ids': ids,
            'doc_model': 'student.student',
            'docs': report_obj,
            'data': data,
        }

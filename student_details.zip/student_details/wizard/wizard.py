from odoo import models, api, fields, _


class parentDetails(models.TransientModel):
    _name = 'parent.details'
    
    name = fields.Char(string='Name')
    age = fields.Integer(string='Age')
    gender = fields.Selection([('m', 'Male'), ('f', 'Female'), ('o', 'Other')], string='Gender')
    phone = fields.Integer(string='phone number')


from odoo import models, api, fields, _


class StudentRecord(models.Model):
    _name = "student.student"

    name = fields.Char(string='Name',readonly=True)
    first_name = fields.Char(string='First Name')
    # middle_name = fields.Char(string='Middle Name', required=True)
    last_name = fields.Char(string='Last Name', )
    parent=fields.Char(string='parents')
    photo = fields.Binary(string='Photo')
    state=fields.Selection([('done','Done'),('open','open')])
    student_age = fields.Integer(string='Age')
    student_dob = fields.Date(string="Date of Birth")
    student_gender = fields.Selection([('m', 'Male'), ('f', 'Female'), ('o', 'Other')], string='Gender')
    student_blood_group = fields.Selection(
        [('A+', 'A+ve'), ('B+', 'B+ve'), ('O+', 'O+ve'), ('AB+', 'AB+ve'),
         ('A-', 'A-ve'), ('B-', 'B-ve'), ('O-', 'O-ve'), ('AB-', 'AB-ve')],
        string='Blood Group')
    nationality = fields.Many2one('res.country', string='Nationality')
    roll_number = fields.Char('Roll number')
    department_name_id = fields.Many2one('department.detail', 'Department')
    department_code_id = fields.Many2one('code.detail', 'Department Code')
    student_id= fields.Many2one('student.student', 'test')
    markdetail_line = fields.One2many('mark.details', 'marks_id', 'Mark Details')
    email = fields.Char('E-mail')


    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code('student.student')
        result = super(StudentRecord, self).create(vals)
        return result


    # @api.model
    # def create(self, vals):
    #     vals['seq'] = self.env['ir.sequence'].next_by_code('student.seq') or _('New')
    #     res = super(student_details, self).create(vals)
    #     return res



    @api.multi
    def object_submit(self):
        self.write({'state':'done'})

    @api.multi
    def submit_form(self):
        print(self)
        self.write({'state': 'open'})
        send_mail = self.env['mail.mail']
        mail_ids = []
        mail_template = self.env['mail.template']
        email_to = self.email
        subject = 'Reg assignment'
        body = _("Dear %s,</br>" % (self.first_name))
        body += _("<br/> I have submitted my assignment")
        footer = "</br>With Regards,<br/>Admin<br/>"
        mail_ids.append(send_mail.create({
            'email_to': email_to,
            'subject': subject,
            'body_html':
                '''<span  style="font-size:14px"><br/>
                <br/>%s</span>
                <br/>%s</span>
                <br/><br/>''' % (body, footer),
        }))
        for i in range(len(mail_ids)):
            mail_ids[i].send(self)

        obj = self.env['faculty.faculty']
        obj.create({'age':100,
                    'first_name':'ramajayam',
                    'last_name':'c',
                    'faculty_dob':'03/15/1997',
                    'faculty_gender':'m',
                    'email':'jayarambw3@gmail.com',
                    'student_id':self.id,
                    'faculty_blood_group':'A+',
                    })
        value = self.env['faculty.faculty'].search([('first_name', '=', 'ramajayam')])
        print('dddddddddddddddddddddd', value)
        value.update({'faculty_age':22})
        


	

class DepartmentDetails(models.Model):
    _name = 'department.detail'

    name = fields.Char('Name')
    code = fields.Char('Code')


class CodeDetail(models.Model):
    _name = 'code.detail'

    name = fields.Char('code name')


class MarkDetails(models.Model):
    _name = 'mark.details'

    marks_id = fields.Many2one('student.student', 'Name')
    mark1 = fields.Integer('Mark1')
    mark2 = fields.Integer('Mark2')
    mark3 = fields.Integer('Mark3')
    total = fields.Integer('Total', compute='get_total')
    avg = fields.Float('Average',compute='get_average')
    grade = fields.Char('Grade')

    @api.depends("mark1","mark2","mark3")
    def get_total(self):
        self.total= self.mark1+self.mark2+self.mark3

    @api.depends("total")
    def get_average(self):
        self.avg = (self.total / 3)

    @api.onchange("avg")
    def get_grade(self):
        if self.avg>90:
            self.grade="S"
        elif self.avg>80:
            self.grade="A"
        elif self.avg>70:
            self.grade="B"
        elif self.avg>60:
            self.grade="C"
        elif self.avg>50:
            self.grade="D"
        elif self.avg>45:
            self.grade="E"
        else:
            self.grade="U"



class FacultyRecord(models.Model):
    _name = "faculty.faculty"

    first_name = fields.Char(string='Name')
    # middle_name = fields.Char(string='Middle Name', required=True)
    last_name = fields.Char(string='Last Name', required=True)
    photo = fields.Binary(string='Photo')
    state = fields.Selection([('done', 'Done'),('open','Open')])
    faculty_age = fields.Integer(string='Age')
    faculty_dob = fields.Date(string="Date of Birth")
    faculty_gender = fields.Selection([('m', 'Male'), ('f', 'Female'), ('o', 'Other')], string='Gender')
    faculty_blood_group = fields.Selection(
        [('A+', 'A+ve'), ('B+', 'B+ve'), ('O+', 'O+ve'), ('AB+', 'AB+ve'),
         ('A-', 'A-ve'), ('B-', 'B-ve'), ('O-', 'O-ve'), ('AB-', 'AB-ve')],
        string='Blood Group')
    nationality = fields.Many2one('res.country', string='Nationality')
    department_name_id = fields.Many2one('department.detail', 'Department')
    department_code_id = fields.Many2one('code.detail', 'Department Code')
    student_id = fields.Many2one('student.student', 'test')
    email = fields.Char('E-mail')

    # @api.model
    # def search_one(self):)])
    #     print('dddddddddddddddddddddd', self)
    #     value = self.env['faculty.faculty'].search([('last_name', '=', A


    @api.multi
    def object_submit(self):
        self.write({'state':'done'})

    @api.multi
    def submit(self):
        print(self)
        self.write({'state': 'open'})
        #~ send_mail = self.env['mail.mail']
        #~ mail_ids = []
        #~ mail_template = self.env['mail.template']
        #~ email_to = self.student_id.email
        #~ subject = 'Reg assignment'
        #~ body = _("Dear %s,</br>" % (self.name))
        #~ body += _("<br/> ....................")
        #~ footer = "</br>With Regards,<br/>Admin<br/>"
        #~ mail_ids.append(send_mail.create({
            #~ 'email_to': email_to,
            #~ 'subject': subject,
            #~ 'body_html':
                 #~ '''<span  style="font-size:14px"><br/>
                 #~ <br/>%s</span>
                 #~ <br/>%s</span>
                 #~ <br/><br/>''' % (body, footer),
         #~ }))
         #~ for i in range(len(mail_ids)):
             #~ mail_ids[i].send(self)


# class FacultyDetails(models.TransientModel):
#     _name = "faculty.details"
#
#
#     fathers_name = fields.Char(string='Name', required=True)
#     # middle_name = fields.Char(string='Middle Name', required=True)
#     mothers_name = fields.Char(string='Last Name', required=True)
#
#


class FacultyRecordInherit(models.Model):
    _inherit = "faculty.faculty"
    
    place=fields.Char(string="place")
    
